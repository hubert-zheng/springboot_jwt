package com.crland.tenant.auth.api.logback;

import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import java.io.IOException;

public class LogBackExEncoder extends PatternLayoutEncoder {
    public LogBackExEncoder() {
    }

    public void doEncode(ILoggingEvent event) throws IOException {
        super.doEncode(event);
    }

    static {
        PatternLayout.defaultConverterMap.put("TID", ThreadNumConverter.class.getName());
        PatternLayout.defaultConverterMap.put("threadNum", ThreadNumConverter.class.getName());
    }
}
