package com.crland.tenant.auth.api.startup;

import com.alibaba.druid.pool.DruidDataSource;
import com.github.pagehelper.PageHelper;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;
import java.util.Properties;

@Configuration
public class DatabaseConfig {

    @Value("${datasource.url}")
    private String url;
    @Value("${datasource.username}")
    private String userName;
    @Value("${datasource.password}")
    private String password;
    @Value("${datasource.initialSize}")
    private int initialSize;
    @Value("${datasource.maxActive}")
    private int maxActive;
    @Value("${datasource.removeAbandoned}")
    private boolean removeAbandoned;
    @Value("${datasource.removeAbandonedTimeout}")
    private int removeAbandonedTimeout;


    @Bean
    public DataSource dataSource() {
        DruidDataSource druidDataSource = new DruidDataSource();
        druidDataSource.setUrl(this.url);
        druidDataSource.setUsername(this.userName);
        druidDataSource.setPassword(this.password);
        druidDataSource.setInitialSize(this.initialSize);
        druidDataSource.setMaxActive(this.maxActive);
        druidDataSource.setRemoveAbandoned(this.removeAbandoned);
        druidDataSource.setRemoveAbandonedTimeout(this.removeAbandonedTimeout);
        return druidDataSource;
    }



//    @Autowired
//    private DataSource dataSource;

    @Bean(name = "sqlSessionFactory")
    public SqlSessionFactory sqlSessionFactory() throws Exception {
        final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());

        PageHelper pageHelper = new PageHelper();
        Properties props = new Properties();
        props.setProperty("reasonable", "true");
        props.setProperty("supportMethodsArguments", "true");
        props.setProperty("dialect","oracle");
        props.setProperty("rowBoundsWithCount","true");
        pageHelper.setProperties(props);

        sessionFactory.setPlugins(new Interceptor[]{ pageHelper});
        return sessionFactory.getObject();
    }
}
