package com.crland.tenant.auth.api.logback;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

public class ThreadNumConverter extends ClassicConverter {
    public ThreadNumConverter() {
    }

    public String convert(ILoggingEvent event) {
        return String.valueOf(Thread.currentThread().getId());
    }
}
