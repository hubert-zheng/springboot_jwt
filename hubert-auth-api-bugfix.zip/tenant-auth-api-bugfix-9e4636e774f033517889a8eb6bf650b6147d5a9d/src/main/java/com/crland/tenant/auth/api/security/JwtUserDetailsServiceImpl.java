package com.crland.tenant.auth.api.security;

import com.crland.tenant.auth.api.utils.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.cache.RedisCache;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class JwtUserDetailsServiceImpl implements UserDetailsService{

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
//        RedisCache sharedCache = RedisUtil.getOauthSharedCache();
//        DIYUser exitUser = (DIYUser) sharedCache.get("AUTHENTICATED_USERNAME" + userName);
        //osp获取登陆信息
        DIYUser user = null;
        //判断是否在缓存中，若不在缓存也不在osp则抛异常
        if("admin".equalsIgnoreCase(userName)) {
            BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
            user = new DIYUser();
            user.setLoginName(userName);
            user.setPassWord(encoder.encode("admin"));
        }
        //admin时新建下
        if(null == user) {

            throw new UsernameNotFoundException(String.format("No user found with username '%s'.", "userName"));

        }else{
            //返回前可放进缓存中
            return UserFactory.createUser(user);
        }

    }
}
