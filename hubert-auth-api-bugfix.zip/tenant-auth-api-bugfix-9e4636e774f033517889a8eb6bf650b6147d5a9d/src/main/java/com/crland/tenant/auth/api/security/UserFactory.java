package com.crland.tenant.auth.api.security;

import java.util.Date;

public final class UserFactory {
    private UserFactory() {
    }

    public static UserInfo createUser(DIYUser user){
        return new UserInfo(user.getLoginName(), user.getPassWord(),new Date());
    }

}
