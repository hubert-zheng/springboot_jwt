package com.crland.tenant.auth.api.utils;

import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.data.redis.cache.RedisCache;

public class RedisUtil {
    private RedisUtil() {
    }

    /**
     * 返回用户缓存
     * @return
     */
    public static RedisCache getOauthSharedCache() {
        SimpleCacheManager cacheManager = (SimpleCacheManager)SpringContextUtils.getBean("tenantAuthCacheManager");
        RedisCache sharedCache = (RedisCache)cacheManager.getCache("tenant_oauth_api");
        return sharedCache;
    }

}
