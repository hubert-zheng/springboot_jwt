package com.crland.tenant.auth.api.startup;

import com.crland.tenant.auth.api.utils.IniUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.ErrorPage;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.support.StandardServletEnvironment;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = {"com.crland.tenant.auth.api"})
public class TenantAuthApi extends SpringBootServletInitializer implements EmbeddedServletContainerCustomizer {
    public static void main(String[] args)
    {
        HashMap<String, Object> props = new HashMap();
        props.put("security.basic.enabled", Boolean.FALSE);
        props.put("shiro.enabled", Boolean.FALSE);
        props.put("logging.level.org.springframework.security", "INFO");
        ConfigurableEnvironment environment = new StandardServletEnvironment();
        SpringApplication app = new SpringApplication(TenantAuthApi.class);
        app.setBannerMode(Banner.Mode.OFF);
        app.setWebEnvironment(Boolean.TRUE.booleanValue());
        app.setDefaultProperties(props);
        app.setEnvironment(environment);
        Set<Object> sources = new HashSet();
        //sources.add("classpath:spring/spring-context-bpm.xml");
        app.setSources(sources);
        app.run(TenantAuthApi.class, args);
    }

    public void customize(ConfigurableEmbeddedServletContainer container) {
        try {
            IniUtil iniUtil = new IniUtil();
            Properties p = iniUtil.loadFileFromClassPath("application.properties");
            String profile = p.getProperty("spring.profiles.active");
            String contextPath = p.getProperty("server.contextPath");
            Boolean isApiApplication = StringUtils.contains(contextPath, "api");
            if (!isApiApplication.booleanValue() && !"sit".equalsIgnoreCase(profile) && !"uat".equalsIgnoreCase(profile) && !"prod".equalsIgnoreCase(profile)) {
                container.setAddress(InetAddress.getByName("localhost"));
            } else {
                container.setAddress(InetAddress.getLocalHost());
                System.out.println(InetAddress.getLocalHost().getHostAddress());
                System.out.println(InetAddress.getLocalHost().getHostName());
            }

            container.addErrorPages(new ErrorPage[]{new ErrorPage(HttpStatus.NOT_FOUND, "/error")});
            container.addErrorPages(new ErrorPage[]{new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, "/error")});
        } catch (UnknownHostException var7) {
            var7.printStackTrace();
        } catch (IOException var8) {
            var8.printStackTrace();
        }
    }

//    @Bean
//    public HTTPBearerAuthorizeInterceptor localeInterceptor() {
//        //解决拦截器里获取不到@value的值
//        return new HTTPBearerAuthorizeInterceptor();
//    }
//
//    @Override
//    public void addInterceptors(InterceptorRegistry registry) {
//        registry.addInterceptor(localeInterceptor());
//    }

//    @Bean
//    public CorsFilter corsFilter() {
//        UrlBasedCorsConfigurationSource urlBasedCorsConfigurationSource = new UrlBasedCorsConfigurationSource();
//        CorsConfiguration corsConfiguration = new CorsConfiguration();
//        corsConfiguration.setAllowCredentials(true);
//        corsConfiguration.addAllowedOrigin("*");
//        corsConfiguration.addAllowedHeader("*");
//        corsConfiguration.addAllowedMethod("*");
//        urlBasedCorsConfigurationSource.registerCorsConfiguration("/**", corsConfiguration);
//        return new CorsFilter(urlBasedCorsConfigurationSource);
//    }
//
//    public void addCorsMappings(CorsRegistry registry) {
//        registry.addMapping("/**").allowedHeaders(new String[]{"*"}).allowedMethods(new String[]{"*"}).allowedOrigins(new String[]{"*"});
//    }
}
