package com.crland.tenant.auth.api.Controller;

import com.crland.tenant.auth.api.oauth.ResultMsg;
import com.crland.tenant.auth.api.oauth.ResultStatusCode;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/tests")
public class TestController {

    @RequestMapping("/queryUser")
    @ResponseBody
    public ResultMsg queryUser(){
        return new ResultMsg(ResultStatusCode.OK.getErrcode(),ResultStatusCode.OK.getErrmsg(),null);
    }

}
