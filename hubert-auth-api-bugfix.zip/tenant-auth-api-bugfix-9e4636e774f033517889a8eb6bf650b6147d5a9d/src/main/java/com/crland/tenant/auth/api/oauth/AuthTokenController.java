package com.crland.tenant.auth.api.oauth;

import com.crland.tenant.auth.api.security.DIYUser;
import com.crland.tenant.auth.api.security.UserInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * token生成器
 * Created by Hubrt on 2017/9/12.
 */
@RestController
public class AuthTokenController {
//    @Value("${oauth.audience}")
//    private String AuthAudience;   //接受者
//    @Value("${oauth.issuer}")
//    private String authIssuer;   //签发者
//    @Value("${oauth.secret}")
//    private String authSecret;    //密钥
//    @Value("${oauth.expiresSecond}")
//    private String authExpiresSecond;  //过期时间
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private UserDetailsService userDetailsService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;


    /**
     * 获取token
     * @param user
     * @return
     */
    @RequestMapping(value = "/oauth/getToken",method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResultMsg getAccessToken(@RequestBody DIYUser user){
        ResultMsg resultMsg;
        if(StringUtils.isBlank(user.getLoginName())){
            resultMsg = new ResultMsg(ResultStatusCode.NOT_USER_PASSWORD.getErrcode(),ResultStatusCode.NOT_USER_PASSWORD.getErrmsg(),null);
            return resultMsg;
        }
        //通过OSP验证账号密码

        //暂时测试
        if("admin".equals(user.getLoginName()) && "admin".equals(user.getPassWord())) {
            BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
            UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(user.getLoginName(),user.getPassWord());
            //验证token
            final Authentication authentication = authenticationManager.authenticate(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);

            final UserInfo userDetails = (UserInfo) userDetailsService.loadUserByUsername(user.getLoginName());
            final String tokenString = jwtTokenUtil.generateToken(userDetails);

            AccessToken accessToken =  new AccessToken(tokenString,new Date().getTime());
            resultMsg = new ResultMsg(ResultStatusCode.OK.getErrcode(), ResultStatusCode.OK.getErrmsg(), accessToken);
            return resultMsg;
        }

        resultMsg = new ResultMsg(ResultStatusCode.INVALID_LOGIN.getErrcode(), ResultStatusCode.INVALID_LOGIN.getErrmsg(), null);
        return resultMsg;
    }

    /**
     * 刷新token
     * @param token
     * @return
     */
    @RequestMapping(value = "/oauth/refreshToken",method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ResultMsg refreshToken(@RequestBody AccessToken token){
        String tokenString = jwtTokenUtil.refreshToken(token.getAccess_token());
        if(StringUtils.isNotBlank(tokenString)){
            AccessToken accessToken =  new AccessToken(tokenString,new Date().getTime());
            return new ResultMsg(ResultStatusCode.OK.getErrcode(),ResultStatusCode.OK.getErrmsg(),accessToken);
        }else{
            return new ResultMsg(ResultStatusCode.INVALID_TOKEN.getErrcode(),ResultStatusCode.INVALID_TOKEN.getErrmsg(),null);
        }

    }

}
