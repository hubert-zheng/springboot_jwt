package com.crland.tenant.auth.api.oauth;

import com.alibaba.fastjson.JSON;
import com.crland.tenant.auth.api.security.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * JWT权限验证拦截器
 * Created by Hubrt on 2017/9/12.
 */
@Component
public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {

    @Value("${jwt.header}")
    private String tokenHeader;  //实例是在初始化时手动new的，而不是交给spring来管理
    @Value("${jwt.tokenBearer}")
    private String jwtTokenBearer;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private UserDetailsService userDetailsService; // Spring会自动寻找同样类型的具体类注入，这里就是JwtUserDetailsServiceImpl了

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String authHeader = request.getHeader(this.tokenHeader);
        if (authHeader != null && authHeader.startsWith(jwtTokenBearer)) {
            final String authToken = authHeader.substring(jwtTokenBearer.length()); //tokenBearer后面的部分
            String username = jwtTokenUtil.getUsernameFromToken(authToken);
            //logger.info("checking authentication " + username);
            if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserInfo userDetails = (UserInfo) this.userDetailsService.loadUserByUsername(username);
                //token校验
                if (jwtTokenUtil.validateToken(authToken, userDetails)) {
                    UsernamePasswordAuthenticationToken authentication =  new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
                    //设置authentication
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(
                            request));
                    //logger.info("authenticated user " + username + ", setting security context");
                    SecurityContextHolder.getContext().setAuthentication(authentication);

                }
            }

        }

        filterChain.doFilter(request, response);
    }
}
