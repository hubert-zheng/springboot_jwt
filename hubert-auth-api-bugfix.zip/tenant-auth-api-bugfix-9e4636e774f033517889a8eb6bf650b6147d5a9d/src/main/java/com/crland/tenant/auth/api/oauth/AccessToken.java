package com.crland.tenant.auth.api.oauth;

/**
 * Created by Hubrt on 2017/9/12.
 */
public class AccessToken {
    private String access_token;
    private long expires_in;  //过期时间
    private long reflash_token;   //token刷新

    public AccessToken(){}

    public AccessToken(String access_token, long expires_in) {
        this.access_token = access_token;
        this.expires_in = expires_in;
    }

    public AccessToken(String access_token, long expires_in,long reflash_token) {
        this.access_token = access_token;
        this.expires_in = expires_in;
        this.reflash_token = reflash_token;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public long getExpires_in() {
        return expires_in;
    }

    public void setExpires_in(long expires_in) {
        this.expires_in = expires_in;
    }

    public long getReflash_token() {
        return reflash_token;
    }

    public void setReflash_token(long reflash_token) {
        this.reflash_token = reflash_token;
    }
}
