////////////////////////////////////////////////////////////////////////////////
// 项目名称: 华润置地商业ERP项目 - 租户项目.
// Copyright (C)华润置地有限公司 All rights reserved.
////////////////////////////////////////////////////////////////////////////////
package com.crland;

import com.crland.tenant.auth.api.startup.TenantAuthApi;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = TenantAuthApi.class)
@WebAppConfiguration
public class MptDemoWebApplicationTests {

	@Test
	public void contextLoads() {
	}

}
